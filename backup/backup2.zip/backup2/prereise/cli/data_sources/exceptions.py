class CommandNotSupportedError(Exception):
    pass
